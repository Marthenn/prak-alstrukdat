#include <stdio.h>
#include "listlinier.h"

int main(){
    List l;
    CreateList(&l);
    displayList(l);
    insertFirst(&l,8);
    insertFirst(&l,7);
    insertLast(&l,9);
    displayList(l);
    printf("%d\n",length(l));

    List l2;
    CreateList(&l2);
    insertLast(&l2,1);
    insertLast(&l2,2);
    insertLast(&l2,3);
    List l3 = concat(l,l2);
    displayList(l3);
    insertAt(&l3,10,2);
    displayList(l3);
    int res;
    deleteAt(&l3,2,&res);
    printf("%d\n",res);
    displayList(l3);
    return 0;
}