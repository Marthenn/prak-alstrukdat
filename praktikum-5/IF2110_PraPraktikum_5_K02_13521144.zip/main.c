#include <stdio.h>
#include "wordmachine.h"

int main(){
    printf("Hello world!\n");
}